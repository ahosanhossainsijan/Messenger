
<!DOCTYPE html>
<html>

<head>

	<title>xCompany</title>
	<link rel="stylesheet" type="text/css" href="Home.css">

</head>

<body>

	<section class="sec-index">
	
		<img src="Capture.PNG" alt="xCompany" class="logo-img">

		<div class="right-float">

			<p><a href="Home.php"><u>Home</u></a> | <a href="Login.php"><u>Login</u></a> | <a href="Reg.php"><u>Registration</u></a>

		</div>

		<h3>Welcome to xCompany</h3>

		<p class="copyright">Copyright &copy; 2017<p>

	</section>
</body>
</html>